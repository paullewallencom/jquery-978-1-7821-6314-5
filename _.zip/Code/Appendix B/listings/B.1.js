/******************************************************************************
  Normally, tests would appear in a separate file named
  test/test.js, but for our examples it's convenient to place this
  test code in the same JavaScript file as the code that calls it.
******************************************************************************/

module('Selecting');

test('Child Selector', function() {
  // tests go here
});

test('Attribute Selectors', function() {
  // tests go here
});

module('Ajax');

/******************************************************************************
  End test code; begin custom script code.
******************************************************************************/
