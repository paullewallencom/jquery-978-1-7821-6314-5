function addHighlightClass()  {
  $('div.poem-stanza').addClass('highlight');
}

$(document).ready(addHighlightClass);